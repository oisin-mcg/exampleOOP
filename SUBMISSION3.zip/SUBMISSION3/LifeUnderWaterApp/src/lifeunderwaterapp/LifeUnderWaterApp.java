/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lifeunderwaterapp;

/**
 *
 * @author CamaraAdmin
 */
public class LifeUnderWaterApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Create an instance of LifeUnderWaterGUI
        LifeUnderWaterGUI lifeUnderWaterGUI = new LifeUnderWaterGUI();
        
        // Make the GUI visible
        lifeUnderWaterGUI.setVisible(true);
    }
    
}
