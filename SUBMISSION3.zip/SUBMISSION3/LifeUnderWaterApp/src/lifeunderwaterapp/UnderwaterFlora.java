/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lifeunderwaterapp;

/**
 *Array handling class 
 * @author mcgil
 */
//basic code to create objects for array for the flora dex 

public class UnderwaterFlora {
    //constr
    private String name;
    
    //method
    public UnderwaterFlora(String name) {
        this.name = name;
    }
   
    //getter
    public String getName() {
        return name;
    }
}
