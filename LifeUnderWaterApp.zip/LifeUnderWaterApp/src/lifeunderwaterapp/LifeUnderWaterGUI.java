/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lifeunderwaterapp;

import javax.swing.*;
import java.awt.*;

public class LifeUnderWaterGUI extends JFrame {
    private JPanel mainPanel;
    private JButton homeButton, floraButton, wildlifeButton, pollutionButton;

    public LifeUnderWaterGUI() {
        setTitle("Life Under Water App");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        mainPanel = new JPanel(new CardLayout());

        //pages
        JPanel homePanel = createPage("Home Page", "Welcome to the Home Page");
        JPanel floraPanel = createPage("Flora Page", "Explore the underwater flora here");
        JPanel wildlifePanel = createPage("Wildlife Page", "Discover the underwater wildlife here");
        JPanel pollutionPanel = createPage("Pollution Page", "Learn about underwater pollution");

        mainPanel.add(homePanel, "Home");
        mainPanel.add(floraPanel, "Flora");
        mainPanel.add(wildlifePanel, "Wildlife");
        mainPanel.add(pollutionPanel, "Pollution");

        //nav buttons
        homeButton = createNavigationButton("Home", "Home");
        floraButton = createNavigationButton("Flora", "Flora");
        wildlifeButton = createNavigationButton("Wildlife", "Wildlife");
        pollutionButton = createNavigationButton("Pollution", "Pollution");

        //buttons to a navigation bar
        JPanel navBarPanel = new JPanel();
        navBarPanel.add(homeButton);
        navBarPanel.add(floraButton);
        navBarPanel.add(wildlifeButton);
        navBarPanel.add(pollutionButton);

        //components to the main frame
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(navBarPanel, BorderLayout.NORTH);
        getContentPane().add(mainPanel, BorderLayout.CENTER);

        //button actions
        homeButton.addActionListener(e -> showPage("Home"));
        floraButton.addActionListener(e -> showPage("Flora"));
        wildlifeButton.addActionListener(e -> showPage("Wildlife"));
        pollutionButton.addActionListener(e -> showPage("Pollution"));
    }

    private JPanel createPage(String title, String content) {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.add(new JLabel(title, SwingConstants.CENTER), BorderLayout.NORTH);
        panel.add(new JTextArea(content), BorderLayout.CENTER);
        return panel;
    }

    private JButton createNavigationButton(String text, String actionCommand) {
        JButton button = new JButton(text);
        button.setActionCommand(actionCommand);
        return button;
    }

    private void showPage(String pageName) {
        CardLayout cardLayout = (CardLayout) mainPanel.getLayout();
        cardLayout.show(mainPanel, pageName);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LifeUnderWaterGUI app = new LifeUnderWaterGUI();
            app.setVisible(true);
        });
    }
}
